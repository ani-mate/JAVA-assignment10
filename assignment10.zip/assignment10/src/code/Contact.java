package code;
import java.util.*;
import java.io.Serializable;
public class Contact implements Serializable, Comparable<Contact>{

	private int contactID;
	private String contactName;
	private String emailAddress;
	private List<String> contactNumber = new ArrayList<String>();
	
	public int getContactID() { return contactID; }
	public String getContactName() { return contactName; }
	public String getEmail() { return emailAddress; }
	public List<String> getContactNumber() { 
		if(contactNumber.isEmpty()) {return null;}
		return contactNumber; 
		}
	
	public void setContactID(int id) { contactID = id; }
	public void setContactName(String name) { contactName = name; }
	public void setEmail(String email) { emailAddress = email; }
	public void setContactNumber(List<String> contactNo) {
		for(String i : contactNo) {
			if(contactNumber.contains(i)) {continue;}
			else { contactNumber.add(i); }
		}
	}

	public int compareTo(Contact c){
	     return this.contactName.toLowerCase().compareTo(c.contactName.toLowerCase());
	  }
}
