package code;

import java.util.*;

import java.io.*;
import java.sql.*;

class ContactNotFoundException extends Exception{
	public ContactNotFoundException(String s) 
    { 
        super(s); 
    } 
}
public class ContactService {
	
	
	public void displayContacts(List<Contact> contactList) {
		System.out.printf("%20s%20s%20s%20s\n\n","ID","NAME","EMAIL","PHONE NO.");
		System.out.println("----------------------------------------------------------------------------------");
		String firstContact;
		for(Contact i : contactList){
			List<String>temp = i.getContactNumber();
			if(temp == null) {firstContact = "";}
			else {firstContact = temp.get(0);}
			System.out.printf("%20s%20s%20s%20s\n",i.getContactID(),i.getContactName(),i.getEmail(),firstContact);
			if(temp != null) {
				for(String k : temp.subList(1,temp.size())) { System.out.printf("%80s\n",k);	}
			}
			System.out.println("----------------------------------------------------------------------------------");
			
		}
	}
	
	public Contact searchContactByID(int ID, List<Contact> contact) throws ContactNotFoundException{
		for(Contact i : contact) {
			if(i.getContactID() == ID) {
				return i;
			}
		}
		
		return null;
	}
	
	public void addContact(Contact contact,List<Contact> contacts) {
		boolean flag = false;
		if(contacts != null) {
			for(Contact c:contacts) {
				if(c.getContactID() == contact.getContactID()) {flag = true;}
			}
		}
		else {
			contacts.add(contact); 
			System.out.println("Added !");
			}
		if(flag == false) {
			contacts.add(contact);
		System.out.println("Added !");
		}
		
	}
	
	public void removeContact(Contact contact, List<Contact> contacts) throws ContactNotFoundException{
		contacts.remove(contact);
	}
	
	
	public List<Contact> searchContactByName(String name, List<Contact> contact) throws ContactNotFoundException{
		List<Contact> temp = new ArrayList<Contact>();
		for(Contact i : contact) {
			if(name.equalsIgnoreCase(i.getContactName())) {
				temp.add(i);
			}
		}
		return temp;
	}
	
	public List<Contact> searchContactByNumber(String number, List<Contact> contact) throws ContactNotFoundException{
		HashSet<Contact> hset=new HashSet();
		for(Contact i : contact) {
			List<String> contactNumbers = i.getContactNumber();
			if(contactNumbers != null) {
				for(String k: contactNumbers) {
					if(k.contains(number)) {
						hset.add(i);
					}
				}
			}
		}
		List<Contact> clist = new ArrayList<Contact>(hset);
		return clist;
	}
	
	public void addContactNumber(int contactId, String contactNo, List<Contact> contacts) {
		List<String> cno = new ArrayList<String>();
		cno.add(contactNo);
		for(Contact i : contacts) {
			if(contactId == i.getContactID()) {
				i.setContactNumber( cno );
				break;
			}
		}
	}
	
	public void sortContactsByName(List<Contact> contacts) {
		Collections.sort(contacts);
	}
	
	public void readContactsFromFile(List<Contact> contacts, String fileName) {
		Set<Contact> contactSet = new HashSet<Contact>(contacts);
		File cf = new File(fileName);
		try {
			Scanner sc = new Scanner(cf);
			while(sc.hasNextLine()) {
				Contact c = new Contact();
				String[] data = sc.nextLine().split(",");
				c.setContactID(Integer.parseInt(data[0]));
				c.setContactName(data[1]);
				c.setEmail(data[2]);
				List<String> cnumbers = new ArrayList<String>();
				for(int i = 3; i < data.length; i++) {
					cnumbers.add(data[i]);
				}
				c.setContactNumber(cnumbers);
				contactSet.add(c);
			}
			sc.close();
			ContactService cs = new ContactService();
			cs.addContacts(contacts, contactSet);
			System.out.println("Read successfully !");
		}
		catch(FileNotFoundException e) { System.out.println(e); }

	}
	
	public void serializeContactDetails(List<Contact> contacts , String fileName) {
		try {
			FileOutputStream fileOut = new FileOutputStream(fileName);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(contacts);
			out.close();
			fileOut.close();
			System.out.println("\nSerialization Successful...\n");
 
		} 
		catch (Exception e) { System.out.println(e);}
	}
	public List<Contact> deserializeContact(String fileName){
		ArrayList<Contact> contacts = new ArrayList<Contact>();
		try {
			FileInputStream fileIn = new FileInputStream(fileName);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			try {
				contacts=(ArrayList<Contact>)in.readObject();
			} 
			catch (Exception e) {System.out.println(e);}
			in.close();
			fileIn.close();
		} 
		catch (Exception e) {e.printStackTrace();}
		return contacts;
	}
	
	public Set<Contact> populateContactFromDb(){
		Connection conn = MySqlCon.getConnection();
		Set<Contact> contacts = new HashSet<Contact>();
        try {
            String sql = "SELECT * FROM contact_tbl";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while(rs.next()) {
            	Contact c = new Contact();
            	c.setContactID(rs.getInt(1));
            	c.setContactName(rs.getString(2));
            	c.setEmail(rs.getString(3));
            	String temp = rs.getString(4);
            	List<String> cno = new ArrayList<String>();
            	if(temp != null) {
            		String[] data = temp.split(",");
            		for(String i : data) {
            			cno.add(i);
            		}
            	}
            	c.setContactNumber(cno);
            	contacts.add(c);   	
            }
        } 
        catch (Exception e) { System.out.println(e);}
        try { conn.close();}
        catch (SQLException e) {System.out.println(e);}
        return contacts;
	}


	public boolean addContacts(List<Contact> existingContact,Set<Contact> newContacts) {
		boolean flag = false;
		if(newContacts != null) {
			for(Contact nc : newContacts) {
				flag = false;
				if(existingContact != null) {
					for(Contact ec:existingContact) {
						if(ec.getContactID() == nc.getContactID()) {flag = true;}
					}
				}
				else {existingContact.add(nc);}
				if(flag == false) {existingContact.add(nc);}
			}
			return true;
		}
		return false;
	}

}


