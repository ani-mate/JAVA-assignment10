package code;

import java.util.*;
public class Main {

	public static void main(String[] args) {
		List<Contact> contactList = new ArrayList<Contact>();
		Set<Contact> contactDB;
		ContactService cs = new ContactService();
		int count;
		int choice;
		char again ;
		String filepath;
		Scanner sc = new Scanner(System.in);
		do {
			Contact contact = new Contact();
			System.out.println("1. ADD CONTACT");
			System.out.println("2. REMOVE CONTACT");
			System.out.println("3. SEARCH CONTACT BY NAME");
			System.out.println("4. SEARCH CONTACT BY NUMBER");
			System.out.println("5. ADD CONTACT NUMBER");
			System.out.println("6. SORT CONTACTS BY NAME");
			System.out.println("7. READ CONTACTS FROM FILE");
			System.out.println("8. SERIALIZE CONTACT DETAILS");
			System.out.println("9. DESERIALIZE CONTACT DETAILS");
			System.out.println("10. POPULATE CONTACTS FROM DB to Current List");
			System.out.println("11. DISPLAY CURRENT CONTACTS LIST");
			System.out.print("--->");
			choice = Integer.parseInt(sc.nextLine());
			switch(choice) {
				case 1:
					System.out.print("Enter Contact ID : ");
					contact.setContactID(Integer.parseInt(sc.nextLine()));
					System.out.print("Enter Contact Name : ");
					contact.setContactName(sc.nextLine());
					System.out.print("Enter Contact Email : ");
					contact.setEmail(sc.nextLine());
					System.out.print("How many contact numbers do you wish to add ? : ");
					count = Integer.parseInt(sc.nextLine());
					HashSet<String> cnumbers=new HashSet<String>();
					for(int i = 0; i < count; i++) {
						System.out.print("Enter Contact Number : ");
						cnumbers.add(sc.nextLine());
					}
					contact.setContactNumber(new ArrayList<String>(cnumbers));
					
					cs.addContact(contact,contactList);
					
					break;
				case 2:
					cs.displayContacts(contactList);
					try {
						System.out.print("Enter Contact ID : ");
						contact = cs.searchContactByID(sc.nextInt(), contactList);
						sc.nextLine();
						cs.removeContact(contact,contactList);
					}
					catch(ContactNotFoundException e) { System.out.print(e); }
					break;
				case 3:
					try {
						System.out.print("Enter Contact Name : ");
						List<Contact> searchResults = cs.searchContactByName(sc.nextLine(), contactList);
						cs.displayContacts(searchResults);
					}
					catch(ContactNotFoundException e) { System.out.print(e); }
					break;
				case 4:
					try {
						System.out.print("Enter Contact Number : ");
						List<Contact> searchResults = cs.searchContactByNumber(sc.nextLine(), contactList);
						cs.displayContacts(searchResults);
					}
					catch(ContactNotFoundException e) { System.out.print(e); }
					break;
				case 5:
					System.out.print("Enter Contact ID : ");
					int id = sc.nextInt();
					sc.nextLine();
					System.out.print("Enter Contact Number : ");
					String cno = sc.nextLine();
					cs.addContactNumber(id,cno, contactList);
					break;
				case 6:
					cs.sortContactsByName(contactList);
					break;
				case 7:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment10\\src\\textfiles\\Contacts.txt";
					cs.readContactsFromFile(contactList,filepath);
					break;
				case 8:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment10\\src\\textfiles\\SerializedContacts.txt";
					cs.serializeContactDetails(contactList, filepath);
					break;
				case 9:
					filepath = "C:\\Users\\aniket\\Desktop\\assignment\\assignment10\\src\\textfiles\\SerializedContacts.txt";
					cs.displayContacts(cs.deserializeContact(filepath));
					
					break;
				case 10:
					contactDB = cs.populateContactFromDb();
					cs.addContacts(contactList,contactDB);
					break;
				case 11:
					cs.displayContacts(contactList);
					break;
				default:
					
					break;
			}
			System.out.print("Do you wish to continue (y/n) : ");
			again = sc.next().charAt(0);
			sc.nextLine();
		}while(again == 'y');
		System.out.print("END !");
	}

}
